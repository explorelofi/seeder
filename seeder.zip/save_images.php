<?php

// echo '<pre>';
// print_r($_POST);
// echo '</pre>';
// echo '<br /><br />';
echo '<pre>';
print_r($_FILES);
echo '</pre>';
